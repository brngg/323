import java.io.*;
import java.util.*;


public class ChengB_Project1_Main {
	
	public static void processInt(String inFile, String outFile) {
		String data;
		int total = 0;
		int count = 0;
		
		try {
			Scanner input = new Scanner(new FileReader(inFile));
			try {
				BufferedWriter output = new BufferedWriter(new FileWriter(outFile));
				
				while(input.hasNext() == true) {
					data = input.next();
					output.write(data + " ");
					total++;
					count++;
					
					if(count >= 5) {
						output.write("\n");
						count = 0;
					}
					
				}
				
				output.write("\nThe total string count is " + total);
				
				input.close();
				output.close();
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		

	public static void main(String args[]) {
		String inFile = new String(args[0]);
		String outFile = new String(args[1]);
		processInt(inFile, outFile);
	}
}
